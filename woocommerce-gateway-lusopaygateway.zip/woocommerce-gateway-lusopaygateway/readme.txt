=== Multibanco e / ou Payshop (by LUSOPAY) para WooCommerce ===
Contributors: lusopay
Tags: lusopay, multibanco, payshop
Requires at least: 3.9
Tested up to: 4.1.1
Stable tag: 4.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Portuguese payment method that allows you to make payments by ATM and / or Payshop.

== Description ==

Payment method that allows you to make payments by ATM and / or Payshop. Allows the issuance of references ATM and / or Payshop in your online store, which can be paid in ATM or home banking network, and in the case of Payshop in the respective agents (Portugal only).

== Installation ==


1. Go to "Plugins" - > "Add New" and search by Lusopay
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Go to "Woocomerce" -> "Settings" tab and choose the "Checkout" click the link "Lusopaygateway" and enter the key and the nif provided by LUSOPAY.


== Frequently Asked Questions ==

= How i get the key? =

You must go to www.lusopay.com and register and send an email to geral@lusopay.com order to obtain the activation key.